#pragma once

//conversión de TEMPERATURA pasando por Celsius
//Victor Ibañez Aliaga

//incluir a la clase "Temperatura"
enum tipo_conv {
	CTOF, FTOC,
	CTOR, RTOC,
	CTOK, KTOC,
};
